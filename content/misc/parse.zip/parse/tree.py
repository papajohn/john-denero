class Tree:
    def __init__(self, tag, branches):
        assert len(branches) >= 1
        for b in branches:
            assert isinstance(b, Tree) or isinstance(b, Leaf)
        self.tag = tag
        self.branches = branches

class Leaf:
    def __init__(self, tag, word):
        self.tag = tag
        self.word = word

bison = Leaf('N', 'buffalo')
intimidate = Leaf('V', 'buffalo')

s = Tree('S', [Tree('NP', [bison]),
               Tree('VP', [intimidate,
                           Tree('NP', [bison])])])
